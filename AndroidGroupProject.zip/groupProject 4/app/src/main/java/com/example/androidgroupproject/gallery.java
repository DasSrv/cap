package com.example.androidgroupproject;

public class gallery {
    private String paintername;
    private long likedby;
    int id;
    String countryName;
    long population;

    public gallery() {
        super();
    }
    public gallery(int i, String paintername,long likedby) {
        super();
        this.id = i;
        this.paintername = paintername;
        this.likedby=likedby;
    }

    // constructor
    public gallery(String paintername, long likedby){
        this.paintername = paintername;
        this.likedby = likedby;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getCountryName() {
        return paintername;
    }
    public void setpaintername(String paintername) {
        this.paintername = paintername;
    }
    public long getlikedby() {
        return likedby;
    }
    public void setLikedby(long likedby) {
        this.likedby = likedby;
    }

}
