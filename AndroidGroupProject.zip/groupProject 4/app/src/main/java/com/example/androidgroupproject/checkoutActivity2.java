package com.example.androidgroupproject;

import androidx.appcompat.app.AppCompatActivity;

        import android.content.Context;
        import android.content.Intent;
        import android.os.Bundle;
        import android.text.TextUtils;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.database.sqlite.SQLiteDatabase;
        import android.widget.RadioButton;
        import android.widget.RadioGroup;
        import android.widget.Toast;


public class checkoutActivity2 extends AppCompatActivity {
    EditText fullname,quantity,phno;
    Button order;
    private RadioButton radioButton, radioButton2;
    private RadioGroup radioGroup;
    SQLiteDatabase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_checkout);

        fullname = (EditText)findViewById(R.id.fullname);
        quantity = (EditText)findViewById(R.id.quantity);
        phno = (EditText)findViewById(R.id.phno);
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
        radioButton = (RadioButton)findViewById(R.id.radioButton);
        radioButton2 = (RadioButton)findViewById(R.id.radioButton2);

        order =(Button)findViewById(R.id.order);

        db=openOrCreateDatabase("CustomerDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(name VARCHAR,phno VARCHAR,quantity VARCHAR);");

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){



                if(TextUtils.isEmpty(fullname.getText()) || TextUtils.isDigitsOnly(fullname.getText()))
                {

                    fullname.setError("Enter details");
                    fullname.requestFocus();
                    fullname.requestFocus();
                }
                else if (TextUtils.isEmpty(phno.getText()))
                {
                    phno.setError("Enter details");
                    phno.requestFocus();
                }
                else if(TextUtils.isEmpty((quantity.getText())))
                {

                    quantity.setError("Enter details");
                    quantity.requestFocus();
                }
                else if(radioGroup.getCheckedRadioButtonId()== -1)
                {
                    Toast.makeText(checkoutActivity2.this,"Please Select Payment Method",Toast.LENGTH_SHORT).show();
                }
                else {

                    db.execSQL("INSERT INTO student VALUES('"+fullname.getText()+"','"+phno.getText()+
                            "','"+quantity.getText()+"');");

                    Toast.makeText(checkoutActivity2.this, "Order  Placed", Toast.LENGTH_SHORT).show();

                      Intent intent = new Intent(checkoutActivity2.this, Placed.class);
                    startActivity(intent);

                }


            }
        });

    }

}


